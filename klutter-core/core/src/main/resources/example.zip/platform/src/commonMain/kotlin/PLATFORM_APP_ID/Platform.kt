package PLATFORM_APP_ID

@Suppress("NO_ACTUAL_FOR_EXPECT")
expect class Platform() {
    val platform: String
}