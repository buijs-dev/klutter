package com.example.KLUTTER_APP_NAME

@Suppress("NO_ACTUAL_FOR_EXPECT")
expect class Platform() {
    val platform: String
}