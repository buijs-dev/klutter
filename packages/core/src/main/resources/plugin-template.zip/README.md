# Klutter Library

A new Klutter library. 

## Getting Started

This project is a starting point for creating a Flutter
[plug-in package](https://flutter.dev/developing-packages/), 
build made with [Kotlin Multiplatform](https://kotlinlang.org/docs/multiplatform.html#android-and-ios-applications).

A Flutter plugin-package is a specialized package that includes platform-specific 
implementation code for Android and/or iOS. Kotlin Multiplatform is a framework 
used to write and share platform specific code in Kotlin.