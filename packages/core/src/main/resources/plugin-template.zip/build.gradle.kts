buildscript {
    repositories {
        gradlePluginPortal()
        google()
        mavenCentral()
        maven { url = uri("https://repsy.io/mvn/buijs-dev/klutter") }
        maven {
            credentials {
                username = "x"
                password = "x"
            }

            url = uri("x")
        }
    }
    dependencies {
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:KOTLIN_VERSION")
        classpath("com.android.tools.build:gradle:ANDROID_GRADLE_VERSION")
        classpath("dev.buijs.klutter:core:KLUTTER_VERSION")
        classpath("dev.buijs.klutter.gradle:dev.buijs.klutter.gradle.gradle.plugin:KLUTTER_VERSION")
    }
}

repositories {
    google()
    gradlePluginPortal()
    mavenCentral()
    maven { url = uri("https://repsy.io/mvn/buijs-dev/klutter") }
    maven {
        credentials {
            username = "x"
            password = "x"
        }

        url = uri("x")
    }
}

allprojects {

    repositories {
        google()
        gradlePluginPortal()
        mavenCentral()

        maven {
            url = uri("https://repsy.io/mvn/buijs-dev/klutter")
        }

        maven {
            credentials {
                username = "x"
                password = "x"
            }

            url = uri("https://repsy.io/mvn/buijs-dev/klutter-private")
        }
    }

}

tasks.register("clean", Delete::class) {
    delete(rootProject.buildDir)
}

tasks.register("installPlatform") {

    //Install the platform module.
    exec {
        commandLine("bash", "./gradlew", "clean", "build", "-p", "platform")
    }

    //Run flutter pub get to make sure the iOS project is fully setup.
    exec {
        commandLine("bash", "flutter", "pub", "get")
    }

    //Run podupdate script which does a pod install/update to get the latest platform podspec.
    exec {
        commandLine("bash", "./gradlew", "podupdate", "-p", "ios")
    }

}