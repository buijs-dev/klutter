package DEVELOPER_ORGANISATION.LIBRARY_NAME.platform

expect class Platform() {
    val platform: String
}